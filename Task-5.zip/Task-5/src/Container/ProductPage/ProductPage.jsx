import React from 'react'
import Products from '../../Components/Products/Products'
import ProList from '../../Components/ProList/ProList'

function ProductPage() {
  return (
    <>
        <Products/>
        <ProList/>
    </>
  )
}

export default ProductPage