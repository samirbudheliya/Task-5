import './App.css'
import Header from './Components/Header/Header'
import HomePage from './Components/HomePage/HomePage'
import {Routes, Route } from 'react-router'
import ProductPage from './Container/ProductPage/ProductPage'

function App() {

  return (
    <>
      <Header/>
      <main>
        <Routes>
          <Route path='/' element={<HomePage/>} />
          <Route path='/product' element={<ProductPage/>} />
        </Routes>
      </main>
    </>
  )
}

export default App
