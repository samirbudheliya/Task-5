import React from 'react'
import LogoImg from '../../assets/sdLatestLogo.svg'

function Logo() {
  return (
    <>
        <a href="#">
            <img src={LogoImg} alt="sdLatestLogo" />
        </a>
    </>
  )
}

export default Logo