import React from 'react'
import pro1 from '../../assets/pr1.jpeg'
import pro2 from '../../assets/pr2.jpg'
import pro3 from '../../assets/pr3.jpg'
import pro4 from '../../assets/pr4.jpeg'

function TrandingPro() {
  return (
    <>
        <section className='trendingNowWidget'>
            <div className="container">
                <div className="row">
                    <div className="col-12">
                        <div className="widgetHead">
                            <div className="heading text-start">
                                <h2>TRENDING PRODUCTS</h2>
                            </div>
                        </div>
                    </div>
                    <div className="col-3">
                        <div className="running-shose" style={{cursor: 'pointer'}}>
                            <div className="pro-img">
                                <img src={pro1} alt="pr1" />    
                            </div>
                            <div className="shose-content text-start">
                                <p className='product-title'>Bhawna Collection Loard Shiv <br/> Trishul Damru Locket With Puchmukhi Rudraksha Mala Gold-plated Brass, Wood For Men & Women</p>
                                <div className='clearfix rating av-rating'>
                                    <div className="rating-stars">
                                        <div className="grey-stars">
                                            <div className="filled-stars" style={{width:'82.0%', color: '#FFC315'}}>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <p className='product-rating-count'>(30)</p>
                                </div>
                                <div className="product-price-row clearfix">
                                    <div className="lfloat me-3">
                                        <span className='lfloat product-desc-price strike '> <del>Rs 699</del></span>
                                        <span className='lfloat product-price'>Rs 159</span>
                                        <div className="product-discount">
                                            <span>77% Off</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-3">
                        <div className="running-shose" style={{cursor: 'pointer'}}>
                            <div className="pro-img">
                                <img src={pro2} alt="pr2" />    
                            </div>
                            <div className="shose-content text-start">
                                <p className='product-title'>Stay Healthy - Foot Protector <br/> (Free Size)</p>
                                <div className='clearfix rating av-rating'>
                                    <div className="rating-stars">
                                        <div className="grey-stars">
                                            <div className="filled-stars" style={{width:'82.0%', color: '#FFC315'}}>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <p className='product-rating-count'>(76)</p>
                                </div>
                                <div className="product-price-row clearfix">
                                    <div className="lfloat me-3">
                                        <span className='lfloat product-desc-price strike '> <del>Rs 899</del></span>
                                        <span className='lfloat product-price'>Rs 79</span>
                                        <div className="product-discount">
                                            <span>91% Off</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-3">
                        <div className="running-shose" style={{cursor: 'pointer'}}>
                            <div className="pro-img">
                                <img src={pro3} alt="pr3" />    
                            </div>
                            <div className="shose-content text-start">
                                <p className='product-title'>Maxbell USB Rechargeable <br/> Electronic Flameless Lighter</p>
                                <div className='clearfix rating av-rating'>
                                    <div className="rating-stars">
                                        <div className="grey-stars">
                                            <div className="filled-stars" style={{width:'82.0%', color: '#FFC315'}}>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <p className='product-rating-count'>(5)</p>
                                </div>
                                <div className="product-price-row clearfix">
                                    <div className="lfloat me-3">
                                        <span className='lfloat product-desc-price strike '> <del>Rs 699</del></span>
                                        <span className='lfloat product-price'>Rs 169</span>
                                        <div className="product-discount">
                                            <span>76% Off</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-3">
                    <div className="running-shose" style={{cursor: 'pointer'}}>
                            <div className="pro-img">
                                <img src={pro4} alt="pr4" />    
                            </div>
                            <div className="shose-content text-start">
                                <p className='product-title'>Bentag Exerciser Single Spring <br/> Tummy Trimmer</p>
                                <div className='clearfix rating av-rating'>
                                    <div className="rating-stars">
                                        <div className="grey-stars">
                                            <div className="filled-stars" style={{width:'82.0%', color: '#FFC315'}}>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <p className='product-rating-count'>(18)</p>
                                </div>
                                <div className="product-price-row clearfix">
                                    <div className="lfloat me-3">
                                        <span className='lfloat product-desc-price strike '> <del>Rs 1,199</del></span>
                                        <span className='lfloat product-price'>Rs 239</span>
                                        <div className="product-discount">
                                            <span>80% Off</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </>
  )
}

export default TrandingPro