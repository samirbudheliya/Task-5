import React from 'react'
import sh1 from '../../assets/shose-1.webp'
import sh2 from '../../assets/shose-2.webp'
import sh3 from '../../assets/shose-3.webp'
import sh4 from '../../assets/shose-4.webp'

function ProList() {
  return (
    <>
        <section className='mt-4 prolist'>
            <div className="container">
                <div className="row align-items-center">
                    <div className="col-3">
                        <div className="running-shose" style={{cursor: 'pointer'}}>
                            <img src={sh1} alt="shose-1" />
                            <div className="shose-content text-start">
                                <p className='product-title'>JQR - FOCUS Light Grey Men's <br/> Sports Running Shoes</p>
                                <div className="product-price-row clearfix">
                                    <div className="lfloat me-3">
                                        <span className='lfloat product-desc-price strike '> <del>Rs. 1,699</del></span>
                                        <span className='lfloat product-price'>Rs.  1,399</span>
                                        <div className="product-discount">
                                            <span>18% Off</span>
                                        </div>
                                    </div>
                                </div>
                                <div className='clearfix rating av-rating'>
                                    <div className="rating-stars">
                                        <div className="grey-stars">
                                            <div className="filled-stars" style={{width:'82.0%', color: '#FFC315'}}>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <p className='product-rating-count'>(604)</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-3">
                    <div className="running-shose" style={{cursor: 'pointer'}}>
                            <img src={sh2} alt="shose-2" />
                            <div className="shose-content text-start">
                                <p className='product-title'>Aivin County Blue Cricket Shoes</p>
                                <div className="product-price-row clearfix">
                                    <div className="lfloat me-3">
                                        <span className='lfloat product-desc-price strike '> <del>Rs. 1,899</del></span>
                                        <span className='lfloat product-price'>Rs.  775</span>
                                        <div className="product-discount">
                                            <span>59% Off</span>
                                        </div>
                                    </div>
                                </div>
                                <div className='clearfix rating av-rating'>
                                    <div className="rating-stars">
                                        <div className="grey-stars">
                                            <div className="filled-stars" style={{width:'82.0%', color: '#FFC315'}}>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <p className='product-rating-count'>(8)</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-3">
                        <div className="running-shose" style={{cursor: 'pointer'}}>
                            <img src={sh3} alt="shose-3" />
                            <div className="shose-content text-start">
                                <p className='product-title'>Impakto Gray Training Shoes</p>
                                <div className="product-price-row clearfix">
                                    <div className="lfloat me-3">
                                        <span className='lfloat product-desc-price strike '> <del>Rs. 1,899</del></span>
                                        <span className='lfloat product-price'>Rs.  749</span>
                                        <div className="product-discount">
                                            <span>61% Off</span>
                                        </div>
                                    </div>
                                </div>
                                <div className='clearfix rating av-rating'>
                                    <div className="rating-stars">
                                        <div className="grey-stars">
                                            <div className="filled-stars" style={{width:'82.0%', color: '#FFC315'}}>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <p className='product-rating-count'>(6)</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="col-3">
                    <div className="running-shose" style={{cursor: 'pointer'}}>
                            <img src={sh4} alt="shose-4" />
                            <div className="shose-content text-start">
                                <p className='product-title'>RICKENBAC Black Training Shoes</p>
                                <div className="product-price-row clearfix">
                                    <div className="lfloat me-3">
                                        <span className='lfloat product-desc-price strike '> <del>Rs. 1,499</del></span>
                                        <span className='lfloat product-price'>Rs.  575</span>
                                        <div className="product-discount">
                                            <span>62% Off</span>
                                        </div>
                                    </div>
                                </div>
                                <div className='clearfix rating av-rating'>
                                    <div className="rating-stars">
                                        <div className="grey-stars">
                                            <div className="filled-stars" style={{width:'82.0%', color: '#FFC315'}}>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                                <i class="fa-solid fa-star"></i>
                                            </div>
                                        </div>
                                    </div>
                                    <p className='product-rating-count'>(14)</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </>
  )
}

export default ProList