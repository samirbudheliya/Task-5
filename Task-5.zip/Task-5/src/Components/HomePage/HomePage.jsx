import React from 'react'
import HomeBanner from '../HomeBanner/HomeBanner'
import TrandingPro from '../TrandingPro/TrandingPro'

function HomePage() {
  return (
    <>
        <HomeBanner/>
        <TrandingPro/>
    </>
  )
}

export default HomePage