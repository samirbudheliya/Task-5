import React from 'react'

function Products() {
  return (
    <>
        <section className='mt-4'>
            <div className="container">
                <div className="row align-items-center">
                    <div className="col-8">
                        <div className="tegline d-flex align-items-center">
                            <h1> Sports Shoes for Men </h1> 
                            (6308 Items)
                            |
                            <input type="search" id='searchWithinSearch' name="search" placeholder='Search within category' style={{border: 'none', marginLeft: '20px'}}/>
                        </div>
                    </div>
                    <div className="col-4">
                        <div className="shoring">
                            <ul className='list-unstyled'>
                                <li>
                                    <select>
                                        <option value="1">Short by: Popularity</option>
                                        <option value="2">PriceLow To High</option>
                                        <option value="3">PriceHigh To Low</option>
                                        <option value="4">Discount</option> 
                                        <option value="5">Fresh Arrivals</option> 
                                    </select>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div className="chack d-flex justify-content-start mt-4">
                        <input type="search" id='searchWithinSearch' name="search" placeholder='Enter your pincode' style={{border: 'none', marginLeft: '20px'}}/>
                        <button style={{backgroundColor: 'transparent', border: 'none', color: '#e40046', fontSize: '13px'}}>Check</button>
                    </div>
                </div>
            </div>
        </section>
        <div className="border mt-4"></div>
    </>
  )
}

export default Products