import React from 'react'
import bannerImg from '../../assets/banner.jpeg'

function HomeBanner() {
  return (
    <>
        <section className='banner mt-4'>
            <div className="col-12">
                <img src={bannerImg} alt="banner" style={{width: '100%'}}/>
            </div>
        </section>
    </>
  )
}

export default HomeBanner