import Button from 'react-bootstrap/Button';
import { Container, Row } from 'react-bootstrap';
import Form from 'react-bootstrap/Form';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Logo from '../Logo/Logo';
import { NavLink } from 'react-router-dom';

function Header() {
  return (
    <section>
        <header>
            <Navbar expand="lg" className="topbar">
            <Container fluid>
                <Navbar.Brand href="#">
                    <Logo/>
                </Navbar.Brand>
                <Navbar.Toggle aria-controls="navbarScroll" />
                <Navbar.Collapse id="navbarScroll">
                <Nav
                className="me-auto my-2 my-lg-0"
                style={{ maxHeight: '100px' }}
                navbarScroll
                >
                <Nav.Link href="#">
                    <i class="fa-solid fa-bars pe-4" style={{fontSize : '15px', color : 'white'}}></i>
                </Nav.Link>
                <Form className="d-flex">
                    <Form.Control
                    type="search"
                    placeholder="Search products & brands"
                    className=""
                    style={{width: '700px', borderRadius : '0px'}}
                    aria-label="Search"
                    />
                    <Button style={{width: '140px', borderRadius : '0px', backgroundColor: '#3f3f3f', border : 'none'}}>Search</Button>
                </Form>
                </Nav>
                </Navbar.Collapse>
                <NavLink className='me-4' to={'/product'} style={{color : 'white', fontSize : '13px'}}>
                    Product
                </NavLink>
                <Nav.Link className='me-2' style={{color : 'white', fontSize : '13px'}}>
                    Cart
                </Nav.Link>
                    <i class="fa-solid fa-cart-shopping me-3" style={{fontSize: '18px', color : '#fff'}}></i>
                <Nav.Link className='me-2' style={{color : 'white'}}>
                    Sing In
                </Nav.Link>
                <i class="fa-solid fa-user me-3" style={{fontSize: '18px', color : '#fff'}}></i>
            </Container>
            </Navbar>
        </header>
    </section>
  );
}

export default Header;